package com.licenta.bakeryapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BakeryApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(BakeryApiApplication.class, args);
	}

}
