package com.licenta.bakeryapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BakeryApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
