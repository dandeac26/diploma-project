package dev.dandeac.data_api.controller;

public class RecipeController {
}
