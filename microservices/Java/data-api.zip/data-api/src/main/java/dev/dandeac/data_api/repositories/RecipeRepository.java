package dev.dandeac.data_api.repositories;

public interface RecipeRepository {
}
