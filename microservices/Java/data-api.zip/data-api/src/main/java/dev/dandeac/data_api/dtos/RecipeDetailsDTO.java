package dev.dandeac.data_api.dtos;

public class RecipeDetailsDTO {
}
