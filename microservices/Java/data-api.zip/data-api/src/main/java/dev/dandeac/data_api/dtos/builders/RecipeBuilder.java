package dev.dandeac.data_api.dtos.builders;

public class RecipeBuilder {
}
