package dev.dandeac.googlelogin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GoogleLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoogleLoginApplication.class, args);
	}

}
